public interface BouncableFactory {
    Bouncable createCircle(Displayer d);
}
