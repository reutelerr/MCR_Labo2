import java.awt.*;

public interface Renderable {
    void Display(Graphics2D g, Bouncable b);
}
