import java.awt.*;

public interface Renderable {
    public void Display(Graphics2D g, Bouncable b);
}
